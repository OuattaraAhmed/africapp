<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Prendre un RDV</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="style4.css">
</head>
<body>

<?php
include 'db.php';

if(isset($_POST["submit"]))
{ 

        $email=$_POST['email'];
		
		    $mobile=$_POST['mobile'];
        $uname=$_POST['user_name'];
        $description_rdv=$_POST['description_rdv'];
        $cause_rdv=$_POST['cause_rdv'];
        $type_rdv=$_POST['type_rdv'];


        $sql = "SELECT * from user where email='$email' or mobile='$mobile' ";
        $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        // output data of each row
        echo"<h1><font color='red'>Desolé</font>, Vous avez déja pris un RDV <h1>";
      
      }
      else
      {
           $sql = "INSERT INTO user (user_name,email, mobile,description_rdv,cause_rdv,type_rdv)
           VALUES ('$uname', '$email', '$mobile','$description_rdv','$cause_rdv','$type_rdv')";
          
          if (mysqli_query($conn, $sql))
           {
            //  $verif="SELECT id,user_name from user where email='$email'";
             
            //  $result = $conn->query($verif);
            //  if ($result->num_rows > 0) {
            //     $id=$row['id'];
            //     $name=$row['user_name'];

            echo "<h1><font color='green'>Félicitation $uname</font>,  votre demande a été prise en compte </h1>";
            
            $ville=$_POST['ville'];
		
		    
  




            $sql = "SELECT attente_ville from ville where ville='$ville' ";
      
            $result = $conn->query($sql);
          if ($result->num_rows > 0) {
           
            // $compte=$id;
            
            if (mysqli_query($conn, $sql))
            {
             //  $verif="SELECT id,user_name from user where email='$email'";
              
             //  $result = $conn->query($verif);
             //  if ($result->num_rows > 0) {
             //     $id=$row['id'];
             //     $name=$row['user_name'];
    
             
            
           
            // output data of each row
              // $compte=$row['attente_ville'];
    
            $sql = "update ville  set attente_ville=attente_ville+1 where ville='$ville' ";
    
              if (mysqli_query($conn, $sql))
               {
                //  $verif="SELECT id,user_name from user where email='$email'";
                 
                //  $result = $conn->query($verif);
                //  if ($result->num_rows > 0) {
                //     $id=$row['id'];
                //     $name=$row['user_name'];
    
                // echo "<h1>attente enregister </h1>";
                
    
                // }
              } 
              else 
              {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
              }
          
        
    
             
             
    
              // }
            } 
            }






            // }
          } 
          else 
          {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }

      }
    
    


}









   







echo "<a class='btn btn-primary stretched-link' href='index.php'>retour</a>";


mysqli_close($conn);
?>





<!-- 
$email=$_POST["email"];
		$password=$_POST["password"];
		$mobile=$_POST["mobile"];
        $uname=$_POST["user_name"];

        $description_rdv=$_POST["descrption_rdv"];
        $cause_rdv=$_POST["cause_rdv"];
        $type_rdv=$_POST["type_rdv"]; -->


        </body>
</html>