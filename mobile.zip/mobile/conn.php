<?php 
 
include 'db.php';

if(isset($_POST['commune'])){

$commune = $_POST['commune'];


$sql = "SELECT * FROM ville WHERE ville='$commune' ";

$result = $conn->query($sql);
if ($result->num_rows > 0)
 {

    // output data of each row
    while($row = $result->fetch_assoc()) 
    {
       echo $row['ville'], $row['lng'];

    }
  

    

} 
else 
{
    echo "0 results";
}
  
}
$conn->close();
?>
