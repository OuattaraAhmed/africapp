<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="chrome=1">
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no, width=device-width">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="ol.css" type="text/css">
    <link rel="stylesheet" href="layout.css" type="text/css">
    <title>Mobile Geolocation Tracking with Orientation</title>
    <style type="text/css">
      html, body, .map {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
      }
      #info {
          position: absolute;
          font-size: 0.7em;
          top: 10px;
          right: 10px;
          background-color: lightgrey;
          padding: 4px;
      }
      .button {
          position: absolute;
          bottom: 40px;
          left: 10px;
      }
    </style>
    <script src="https://unpkg.com/elm-pep"></script>
    <script src="https://cdn.polyfill.io/v2/polyfill.min.js?features=fetch,requestAnimationFrame,Element.prototype.classList,URL"></script>
  </head>
  <body>
    <div id="map" class="map"></div>
    <div id="info"></div>
    <img id="geolocation_marker" src="data/geolocation_marker.png" />
    <div class="button">
        <button id="geolocate">Geolocate Me!</button>
        <button id="simulate">Simulate</button>
    </div>
    <script src="common.js"></script>
    <script src="geolocation-orientation.js"></script>
  </body>
</html>
