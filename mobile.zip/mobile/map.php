<?php
  include 'db.php';

// $longeur=$lng['lng'];
// $largeur=$lat['lat'];

?>

<html>
  <head>
  <title>OpenLayers Marker Popups</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  </head>
  <body>

  <script language="Javascript">
        function submit_form() {
            if (document.form_recherche.Search.value != "") {
                form_recherche.submit();

            }

        }
    </SCRIPT>

  <div class="container">

       <div class="row text-center "> 
          
          <a class="btn btn-primary stretched-link" href="index.php">retour</a>
       </div>
  


  <div id="mapdiv"></div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/openlayers/2.11/lib/OpenLayers.js"></script> 

  


  <?php 
    if(isset($_POST['Search'])){
      $search = $_POST['Search'];
    $sql = "SELECT * FROM ville WHERE ville LIKE '%$search%' ORDER BY ville";

    } else{
      $sql = "SELECT * FROM ville ";
    }

    if(isset($_POST['commune']))
    {
      $commune = $_POST['commune'];
      $sql = "SELECT * FROM ville WHERE ville='$commune' ";

    } else
    {
      $sql = "SELECT * FROM ville ";
    }
    $result = $conn->query($sql);
 
?>

  <script>
    map = new OpenLayers.Map("mapdiv");
    map.addLayer(new OpenLayers.Layer.OSM());
    
    epsg4326 =  new OpenLayers.Projection("EPSG:4326"); //WGS 1984 projection
    projectTo = map.getProjectionObject(); //The map projection (Spherical Mercator)

    <?php if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

    $id=$row["ville"];

    ?>


    var lonLat = new OpenLayers.LonLat(<?php echo $row["lng"]; ?> , <?php echo $row["lat"]; ?>).transform(epsg4326, projectTo);
          
    
    var zoom=15;
    map.setCenter (lonLat, zoom);

    var vectorLayer = new OpenLayers.Layer.Vector("Overlay");
    
    // Define markers as "features" of the vector layer:
    
   

    var feature = new OpenLayers.Feature.Vector(
            new OpenLayers.Geometry.Point( <?php echo $row["lng"]; ?> , <?php echo $row["lat"]; ?>).transform(epsg4326, projectTo),
            {description:' Agence de <?php echo $row["ville"]; ?>, Attente:<?php echo $row["attente_ville"]; ?> , <a href="rdv.php?id=<?php echo $id; ?> "> Prendre un RDV    </a> '} ,
            {externalGraphic: 'img/marker.png', graphicHeight: 25, graphicWidth: 21, graphicXOffset:-12, graphicYOffset:-25  }
        );    
    vectorLayer.addFeatures(feature);

    <?php
    }
    
  } else {
      echo "0 results";
    }

    mysqli_close($conn);
    ?>
   
    map.addLayer(vectorLayer);
 
    
    //Add a selector control to the vectorLayer with popup functions
    var controls = {
      selector: new OpenLayers.Control.SelectFeature(vectorLayer, { onSelect: createPopup, onUnselect: destroyPopup })
    };

    function createPopup(feature) {
      feature.popup = new OpenLayers.Popup.FramedCloud("pop",
          feature.geometry.getBounds().getCenterLonLat(),
          null,
          '<div class="markerContent">'+feature.attributes.description+'</div>',
          null,
          true,
          function() { controls['selector'].unselectAll(); }
      );
      //feature.popup.closeOnMove = true;
      map.addPopup(feature.popup);
    }

    function destroyPopup(feature) {
      feature.popup.destroy();
      feature.popup = null;
    }
    
    map.addControl(controls['selector']);
    controls['selector'].activate();
      
  </script>
  </div>
</body></html>
    