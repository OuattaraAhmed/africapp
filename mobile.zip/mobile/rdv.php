<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Prendre un RDV</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="style4.css">
</head>
<body>



 <div class="login-page">

 <a  class="btn btn-primary stretched-link" href="index.php">Retour</a> <br>
 </div>


     <?php



if(isset($_GET['id'])){
  
  $_SESSION['id'] = $_GET['id'] ; 

$id=$_GET['id'];

$sql="select * from ville where ville='$id' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

    ?>     
   

    

  <div class="form">
     <h1>Prendre un RDV à l'agence <?php echo  $row['ville'] ; ?></h1>

     
     <div id="message"></div>

    <form class="login-form" id="regform" action="ajaxregister.php" method="POST">

    
    <label for="pet-select">l'agence : </label>
        <select name="ville" id="ville" required>
        <option value="<?php echo  $row['ville']; ?>"><?php echo  $row['ville']; ?></option><br>
            

<?php

    
}
} else {
echo "0 results";
}


}
$conn->close();
?>


      <input type="text" placeholder="Nom" name="user_name" id="user_name" require/>
      <span id="uname"></span>
      <input type="text" placeholder="Email" name="email" id="email" required />
      <span id="uemail"></span>
      <input type="text" placeholder="Telephone" name="mobile" id="mobile" required />
      <span id="umobile"></span>

      <label for="pet-select">cause du RDV : </label>
        <select name="cause_rdv" id="cause_rdv" required >
            <option value="">--Faites un choix--</option>
            <option value="Creer un compte">Creer un compte</option>
            <option value="Retrait">Retrait</option>
            <option value="Depôt">Depôt</option>
            <option value="Verifier son solde">Verifier son solde</option>
        </select><span id="ucause_rdv"></span> <br><br>

        <TEXTAREA name="description_rdv" id="description_rdv" rows=4 cols=35 placeholder="Entrez une description" required ></TEXTAREA>
      <span id="udescription_rdv"></span><br>

        <label for="type_rdv">Type de RDV : </label>
        <select name="type_rdv" id="type_rdv" required >
            <option value="Gratuit"> Gratuit </option>
            <option value="Premium : 500 F CFA ">Premium : 500 F CFA </option>
           
            
        </select> <span id="utype_rdv"></span><br><br>
      <input type="submit" class="btn" name="submit" id="submit" value="Register">
      
    </form>
  </div>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- <script type="text/javascript">
  $("#regform").on("submit",function(e){

   
    $('#uname').html('');
    $('#upass').html('');
    $('#uemail').html('');

    $('#description_rdv').html('');
    $('#cause_rdv').html('');
    $('#types_rdv').html('');


    $('#umobile').html('');
    $('#message').html('');
        
        var user_name=$("#user_name").val();
        var password=$("#password").val();
        var mobile = $("#mobile").val();
        var email = $('#email').val();

        var description_rdv = $('#description_rdv').val();
        var cause_rdv = $('#cause_rdv').val();
        var type_rdv = $('#type_rdv').val();

        if($("#user_name").val()==""){
               $("#uname").html("Please enter username.");
               $("#uname").css("color", "red");
               $("#user_name").css("border", "1px solid grey");
               $("#user_name").focus();
             }
        else if($("#email").val()==""){
              $("#uemail").html("Please enter email.");
               $("#uemail").css("color", "red");
               $("#email").css("border", "1px solid grey");
              $("#email").focus();
        }
        else if($("#mobile").val()==""){
              $("#umobile").html("Please enter mobile.");
               $("#umobile").css("color", "red");
               $("#mobile").css("border", "1px solid grey");
              $("#mobile").focus();
        }
        else if($("#password").val()==""){
              $("#upass").html("Please enter password.");
               $("#upass").css("color", "red");
               $("#password").css("border", "1px solid grey");
              $("#password").focus();
        }
        else if($("#description_rdv").val()==""){
              $("#udescription_rdv").html("Veillez entrez une description.");
               $("#description_rdv").css("color", "red");
               $("#description_rdv").css("border", "1px solid grey");
              $("#description_rdv").focus();
        }
        else if($("#cause_rdv").val()==""){
              $("#ucause_rdv").html("Veillez entrez une cause.");
               $("#cause_rdv").css("color", "red");
               $("#cause_rdv").css("border", "1px solid grey");
              $("#cause_rdv").focus();
        }
        else if($("#type_rdv").val()==""){
              $("#utype_rdv").html("Veillez entrez une description.");
               $("#type_rdv").css("color", "red");
               $("#type_rdv").css("border", "1px solid grey");
              $("#type_rdv").focus();
        }

        
      else
      {
           $.ajax({
            type:"POST",
            url:"ajaxregister.php",
            data:{"user_name":user_name,"password":password,"email":email,"mobile":mobile,"description_rdv":description_rdv,"cause_rdv":cause_rdv, "type_rdv":type_rdv},
            success:function(result){
             if(result==0){
                $("#message").html("Email allready exists.");
                 $("#message").css("color", "red");
                }
                else{
                $("#message").html("Successfully register");
                $("#message").css("color", "green");
           }
          }

    });

}

e.preventDefault();


  });

</script> -->

</body>
</html>